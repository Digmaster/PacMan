Created by Thomas Luppi, Katie Weiss, and John Lake

Run by "python autograder.py"