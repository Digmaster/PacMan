# PacMan
Pacman AI for AI Class

# Scores
q1: 4/4
q2: 5/5
q3: not started
q4: not started
q5: not started
